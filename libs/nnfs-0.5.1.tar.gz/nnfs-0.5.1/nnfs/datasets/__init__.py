from .spiral import create_data as spiral_data
from .vertical import create_data as vertical_data
from .sine import create_data as sine_data
