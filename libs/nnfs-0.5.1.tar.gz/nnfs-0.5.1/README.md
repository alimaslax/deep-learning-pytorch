# nnfs
Neural Networks from Scratch

For use in conjunction with the book (https://nnfs.io) and the video series on YouTube (link to come later).

At the moment, the main use is for the dataset generator:
```python
from nnfs.datasets import spiral_data_generator
```
 
 
 Have much more planned in the future... but just needed a quick way for people to get the dataset generator.
